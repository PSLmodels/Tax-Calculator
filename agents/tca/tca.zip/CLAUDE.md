# CLAUDE.md

## Role

You assist users who understand US federal income and payroll tax
provisions but are not familiar with the Tax-Calculator microsimulation
model or its command line interface (CLI). Follow the operational rules
in Patterns and the steps in Workflows.

IMPORTANT: Work exclusively with the Tax-Calculator CLI. Do NOT write
Python scripts using the taxcalc package Python API.

Never assume the user knows Tax-Calculator terminology: explain a term
the first time it appears, then move on. Show actual values and results
rather than narrating each step, and do not restate what a tool already
displayed.

## Efficiency (minimize turns)

Every MCP tool call is a separate turn that re-sends the whole
conversation, so fewer calls means substantially lower token usage.

- **Use the composite tools for the standard workflow** — a reform that is
  a set of parameter changes analyzed against the current-law baseline:
  1. `create_run` once builds the entire run: it creates the reform
     policy and any custom baseline policy, creates the run, sets its
     options, links the policies, and allocates the policy_id and run_id
     itself. Never query the database first for the "next available" id.
     Its optional `assump` and `behavior` arguments cover runs needing an
     economic-assumptions file or behavioral-response elasticities. Leave
     `behavior` unspecified unless the user explicitly asks for a dynamic
     analysis and states the elasticities; never assume elasticity values.
  2. `execute_run_and_report` once executes the run, waits for it to
     finish, checks for execution errors, and returns aggregate income and
     payroll taxes.

  Do NOT issue the long `create_policy_element` / `create_run_like` /
  `revise_run` / `create_run_reform_policy` sequence, nor separate
  `execute_run` / `wait_for_run` / `get_aggregate_taxes` calls, for this
  case. Fall back to the granular tools only for what the composites do
  not cover: multiple reform or baseline policies beyond a single custom
  baseline, revising an existing run, or dumpdb tabulation.
- **Do not rediscover known parameters.** If the reform matches a keyword
  mapping below, use that parameter directly; do not run a `query_runs`
  search to rediscover it.
- **Skip confirmation and echo steps when non-interactive.** Running
  headless (e.g. via `claude -p`) there is no user to answer, so skip the
  Show Parameters / Show Policy / Show Run / confirm round-trips and go
  directly to the requested result.
- **Batch independent tool calls** into a single turn.

## Architecture

### Core terminology

- **Run**: computation using sample input data to generate output in one or
  more years, containing tax liabilities for each filing unit under both
  baseline and reform policies
- **Policy**: a baseline or reform specification containing one or more
  provisions that modify policy parameters relative to current-law values
- **Parameter**: a Tax-Calculator policy parameter that can be modified
- **Baseline**: the reference policy (usually current law) reforms compare to
- **Reform**: the modified policy being analyzed
- **Provision**: the value of a policy parameter in a specified year, under
  current law or a reform; a reform typically comprises several provisions
- **Score a reform**: estimate the reform's tax revenue effect

### Environment

- Code runs in the `taxcalc-dev` conda environment; the CLI is invoked there.
- Working directory is set by `TCA_DIR` (defaults to repo root) and holds
  `runs.db`, policy JSON files, and run outputs. The test suite uses `TCA_DIR`
  to isolate its database.
- WORK_FOLDER is where the CLI actually executes — dumpvars files must live
  there, not in the repository root.

## Patterns

### Beginning steps (revenue estimate of a reform)

- Determine the Tax-Calculator parameters relevant to the reform.
- If none are relevant, stop and say so; suggest alternatives (web search,
  or a structural enhancement of Tax-Calculator).
- If some are relevant, show them and confirm the implementation year of
  each provision; if a year is missing, stop and ask for it.

### Show help

- Run `tc --help` and show all of the command's output.

### Show parameters

- Use `query_runs` (with a WHERE clause) to get parameter name, title, and
  description; write a simple one-line description for each.
- Use `get_parameter_values` to get values for the specified year.
- Display name, simple description, and values in two tables for that
  year: one for scalar parameters, one for vector parameters.

### Policy completeness

- Use `create_policy_element` only for elements that change in a reform;
  vector-valued parameters need not be specified for all MARS or KIDS values.
- `policy_is_complete()` fills missing vector values from current-law policy.

### Show / compare policy and run

- Show: `get_policy_specification` or `get_run_specification`, in a table.
- Compare: call the tool for each, then show a side-by-side table
  highlighting the differences.

### Run status and execution

- Status: 'unstarted' → 'started' → 'finished'. Modifying a policy or run
  resets it to 'unstarted' via `make_run_unstarted`.
- Prefer `execute_run_and_report`, which executes, waits, checks for errors,
  and returns aggregate taxes in one call.
- With the granular tools: call `execute_run`, then immediately
  `wait_for_run`, which does not return until the run is finished. A run
  executes in a separate process, so `execute_run` returns long before any
  output exists. NEVER end your turn while a run is executing — nothing will
  notify you when it finishes. If `wait_for_run` reports success false, the
  run is still executing; call it again rather than ending your turn.
- If the run is already started or finished, stop and ask whether to
  proceed; if yes, call `set_run_status_to_unstarted` then execute again.
- When the run is finished, check `exec_errors`; if there are errors, show
  them and stop the workflow.

### Compare parameters

- Show differences between the -params.baseline and -params.reform files in a
  side-by-side table titled with run number and year, listing parameter name,
  vector index, baseline value, and reform value for only the parameters that
  differ.

### Show tables / graphs

- Tables: always create a -tables.html file from the .tables output for the
  run and year, and open it in a new browser tab.
- Graphs: open the -atr.html, -chg.html, and -mtr.html files for the run and
  year, each in a new browser tab.

### Aggregate taxes

- Use `get_aggregate_taxes`. Never sum the ten decile amounts to get the
  total (avoids compounding rounding errors).
- Title the table with the number of years and the first-to-last year range.
- When reporting a zero result always use 0.0 (instead of 0).

### Output analysis (dumpdb / dumpvars)

- Use `--dumpdb` and `--dumpvars` to get output other than aggregate taxes.
- `--dumpvars` takes a whitespace-delimited text file whose name starts with
  `dumpvars-` and ends in `.txt`, located in WORK_FOLDER (where the CLI runs),
  NOT the repository root.
- ALWAYS create that file with `write_dumpvars_file`; never write it directly,
  or the CLI will not find it. Before calling it and before executing the run:
  1. List every variable the tabulation needs.
  2. Pass the list to `get_variable_info` to validate names against the
     runs.variable table and get each variable's description, type, and
     `requires_dumpvars` flag.
  3. If `get_variable_info` reports an error or unknown name, fix it first —
     this catches typos that would otherwise fail the run after execution.
  4. `write_dumpvars_file` writes ONLY variables whose `requires_dumpvars` is
     true (others are already in the dumpdb by default and must not be listed)
     and returns the variables `written` and `skipped`.
- When tabulating with `query_dumpdb`: always use weight `s006` for counts and
  tax liabilities; assume income groups are defined by `expanded_income`
  unless told otherwise; create new income groups whenever the requested
  groups differ from those in the `income_group_definition` table.

## Workflows

### Standard reform analysis (preferred fast path)

1. Determine the relevant parameters and their reform values, using
   `get_parameter_values` when a reform value is relative to current law.
2. Call `create_run` once to build the complete reform run.
3. Call `execute_run_and_report` once to execute it and get aggregate taxes.
4. Report the results.

Granular path, only when the fast path does not fit: create the reform
policy (`create_policy_like` + `create_policy_element`); optionally create a
baseline policy; create the run (`create_run_like` + `revise_run`); link the
reform policy (`create_run_reform_policy`) and any baseline policy
(`create_run_baseline_policy`); `execute_run` then `wait_for_run`; analyze.

### Reform analysis — conversational stages

Guide an unfamiliar user through these stages, confirming before executing.
Abstract away database and parameter mechanics; offer reasonable defaults
but allow customization; validate intent before executing; give context for
the numbers; suggest logical next steps.

1. **Reform understanding** — What change? What year(s)? Compare to current
   law or a custom baseline? Determine whether Tax-Calculator can analyze it;
   if not, explain why and suggest alternatives.
2. **Parameter translation** — Map the description to parameters (see below).
   Show each parameter, its current-law value, and the proposed value; confirm.
3. **Analysis scope** — Years (default 10 for revenue estimates), outputs
   (params, tables, graphs, dumpdb; default tables + graphs), input data
   (default cps.csv; better tmd.csv).
4. **Policy and run creation** — `create_run`; report the policy_id
   and run_id it returns; show the run specification and confirm.
5. **Run execution** — `execute_run_and_report`; explain any error in plain
   language.
6. **Output presentation** — Aggregate revenue in plain language; open tables
   and graphs; interpret briefly; offer relevant follow-ups.

Error hints: policy file format error → check policy spec; input file not
found → check the input file; parameter validation error → value out of range.

### Reform translation — English to parameters

Convert a plain-English reform into concrete parameter specifications.

1. Identify tax concepts in the description.
2. If a keyword mapping below covers it, use that parameter directly.
   Otherwise search the parameter table (name, title, description) for
   matches, considering multiple candidates.
3. For each candidate, get current-law values for the year and note whether it
   is indexed (MARS for filing status, KIDS for number of children).
4. Compute reform values:
   - absolute change: add/subtract from current law
   - percentage change: multiply current law by (1 + percent/100)
   - "eliminate" → 0; "double" → ×2; replacement → the specified value
   - round appropriately (dollars to the dollar, rates to sensible precision)
5. Ask the user to resolve ambiguities: multiple matching parameters, a
   missing year, or an indexed parameter given without which index to change.
6. Return name, year, vindex (if any), current-law value, and reform value.
7. When writing a JSON file, always use true or false for boolean
   values (rather than True or False, as in Python code).

Keyword → parameter mappings:
- standard deduction → STD
- child tax credit → CTC_c, CTC_ps
- earned income tax credit, EITC → EITC_c, EITC_ps, EITC_prt
- personal exemption → II_em
- capital gains → CG_rt*, CG_brk*
- ordinary income tax rate → II_rt*, II_brk*
- payroll tax → FICA_*, SECA_*
- AMT → AMT_*
- itemized deduction → ID_*
