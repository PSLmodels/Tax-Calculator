"""
Tax-Calculator-Assistant MCP server that interacts with SQLite databases
"""
# pylint: disable=too-many-lines,broad-exception-caught
import os
import json
import time
import sqlite3
import shutil
import subprocess
from typing import Any
from pathlib import Path
from datetime import datetime
from mcp.server.mcpserver import MCPServer
import taxcalc

MINIMUM_REQUIRED_TAXCALC_VERSION = "6.8.2"
MCP_SERVER_VERSION = "0.18.0"
RUNS_DB_VERSION = "8"

MCP_SERVER_FOLDER = Path(__file__).parent
DEFAULT_WORK_FOLDER = MCP_SERVER_FOLDER.parent
WORK_FOLDER = Path(os.environ.get("TCA_DIR", str(DEFAULT_WORK_FOLDER)))
RUNS_DB_PATH = WORK_FOLDER / "runs.db"
TCA_LOG_PATH = WORK_FOLDER / "tca.log"


# --- General functions and tools:

CREATE_RUNS_DB_STATEMENTS = """
CREATE TABLE run (
  id       INTEGER PRIMARY KEY DEFAULT 1    CHECK(id>=1),
           -- run identifier
  input    TEXT    NOT NULL    DEFAULT 'cps.csv',
           -- name of input data file
  taxyear  INTEGER NOT NULL    DEFAULT 2022 CHECK(taxyear>=2013),
           -- first tax year to simulate (unrelated to policy reform years)
  numyears INTEGER NOT NULL    DEFAULT 1    CHECK(numyears>=1),
           -- number of tax years to simulate
  baseline TEXT    NOT NULL    DEFAULT ''   CHECK(length(baseline)=0),
           -- baseline policy is specified in run_baseline and policy tables
  reform   TEXT    NOT NULL    DEFAULT ''   CHECK(length(reform)=0),
           -- reform policy is specified in run_reform and policy tables
  assump   TEXT    NOT NULL    DEFAULT '',
           -- name of optional assumptions JSON file
  behavior_esf  REAL NOT NULL  DEFAULT 0.0  CHECK(behavior_esf>=0.0 AND
                                                  behavior_esf<=1.0),
           -- behavioral response earnings shift factor value
  behavior_sub  REAL NOT NULL  DEFAULT 0.0  CHECK(behavior_sub>=0.0),
           -- behavioral response substitution elasticity value
  behavior_inc  REAL NOT NULL  DEFAULT 0.0  CHECK(behavior_inc<=0.0),
           -- behavioral response income elasticity value
  behavior_cg   REAL NOT NULL  DEFAULT 0.0  CHECK(behavior_cg<=0.0),
           -- behavioral response capital-gains elasticity value
  params   INTEGER NOT NULL    DEFAULT 1    CHECK(params>=0 AND params<=1),
           -- whether or not to generate params output files
  tables   INTEGER NOT NULL    DEFAULT 1    CHECK(tables>=0 AND tables<=1),
           -- whether or not to generate tables output file
  graphs   INTEGER NOT NULL    DEFAULT 1    CHECK(graphs>=0 AND graphs<=1),
           -- whether or not to generate graphs output files
  dumpdb   INTEGER NOT NULL    DEFAULT 1    CHECK(dumpdb>=0 AND dumpdb <=1),
           -- whether or not to generate dumpdb output file which is SQLite db
  dumpvars TEXT    NOT NULL    DEFAULT '',
           -- name of optional file containing extra dumpdb variables
  status      TEXT NOT NULL    DEFAULT 'unstarted'
                   CHECK(status IN ('unstarted','started','finished')),
  start_time  TEXT NOT NULL    DEFAULT '',
  finish_time TEXT NOT NULL    DEFAULT '',
  exec_errors TEXT NOT NULL    DEFAULT ''
);

CREATE TABLE policy (
  id             INTEGER NOT NULL CHECK(id>=1),
  parameter_name TEXT NOT NULL REFERENCES parameter(name),
  year           INTEGER NOT NULL CHECK(year>=2013 AND year<2100),
  vindex         TEXT NOT NULL,
  value          TEXT NOT NULL CHECK(length(value)>=1),
  UNIQUE(id, parameter_name, year, vindex) ON CONFLICT ABORT
);

CREATE TABLE parameter (  -- policy parameter table
  name        TEXT PRIMARY KEY NOT NULL CHECK(length(name)>=1),
  title       TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  type        TEXT NOT NULL DEFAULT 'float'
              CHECK(type='float' OR type='int' OR type='bool'),
  indexable   INTEGER NOT NULL DEFAULT 0 CHECK(indexable>=0 AND indexable<=1),
  indexed     INTEGER NOT NULL DEFAULT 0 CHECK(indexed>=0 AND indexed<=1),
  vindex_name TEXT NOT NULL DEFAULT ''
              CHECK(vindex_name IN ('', 'MARS', 'KIDS')),
  vindex_value_min INTEGER NOT NULL DEFAULT 0 CHECK(vindex_value_min>=0),
  vindex_value_max INTEGER NOT NULL DEFAULT 0 CHECK(vindex_value_max>=0)
);

CREATE TABLE variable (  -- output variable table
  name              TEXT PRIMARY KEY NOT NULL CHECK(length(name)>=1),
  description       TEXT NOT NULL DEFAULT '',
  type              TEXT NOT NULL DEFAULT 'float'
                    CHECK(type='float' OR type='unchanging_float'
                          OR type='int' OR type='bool'),
  requires_dumpvars INTEGER NOT NULL DEFAULT 1
                    CHECK(requires_dumpvars=0 OR requires_dumpvars=1)
);

CREATE TABLE run_baseline (
  run_id    INTEGER REFERENCES run(id) ON DELETE CASCADE ON UPDATE CASCADE,
  policy_id INTEGER,  -- references policy(id) which is not a primary key
  UNIQUE(run_id, policy_id) ON CONFLICT ABORT
);
CREATE INDEX run_baseline_run_id    ON run_baseline(run_id);
CREATE INDEX run_baseline_policy_id ON run_baseline(policy_id);

CREATE TABLE run_reform (
  run_id    INTEGER REFERENCES run(id) ON DELETE CASCADE ON UPDATE CASCADE,
  policy_id INTEGER,  -- references policy(id) which is not a primary key
  UNIQUE(run_id, policy_id) ON CONFLICT ABORT
);
CREATE INDEX run_reform_run_id    ON run_reform(run_id);
CREATE INDEX run_reform_policy_id ON run_reform(policy_id);

CREATE TABLE version (
  value TEXT NOT NULL CHECK(length(value)>=1)
);
"""


def sqlite_dict_factory(cursor: sqlite3.Cursor, row: sqlite3.Row) -> dict:
    """
    Return SQLite row as a dictionary.
    """
    fields = [column[0] for column in cursor.description]
    return dict(zip(fields, row))


def select_one_row(db_path: Path, sql: str) -> dict[str, Any]:
    """
    Select one result row as a dictionary using sql SELECT statement
    """
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite_dict_factory
        res_dict = conn.cursor().execute(sql).fetchone()
    except Exception as e:
        raise RuntimeError(f"{str({e})} : {sql}") from e
    finally:
        if conn:
            conn.close()
    return res_dict


def select_all_rows(db_path: Path, sql: str) -> list[dict[str, Any]]:
    """
    Select all results row as a list of dictionaries using sql SELECT statement
    """
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite_dict_factory
        res_dict_list = conn.cursor().execute(sql).fetchall()
    except Exception as e:
        raise RuntimeError(f"str({e}) : {sql}") from e
    finally:
        if conn:
            conn.close()
    return res_dict_list


def non_select_execution(db_path: Path, sql: str) -> None:
    """
    Execute non-SELECT command(s) in sql string with foreign_keys active
    on the SQLite database at db_path
    """
    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute("PRAGMA foreign_keys = ON;")
        cur.executescript(sql)
        conn.commit()
    except Exception as e:
        raise RuntimeError(f"{str({e})} : {sql}") from e
    finally:
        if conn:
            conn.close()


def trace(msg: str) -> None:
    """
    Append msg to log file at TCA_LOG_PATH.
    """
    with open(TCA_LOG_PATH, "a", encoding="utf-8") as log:
        log.write(f"{now()}: {msg}\n")


def add_parameter_rows(cur: sqlite3.Cursor) -> None:
    """
    Add parameter table rows containing Tax-Calculator Policy metadata
    using the specified cur SQLite cursor
    """
    str_fnames = [
        "title",
        "description",
        "type",
    ]
    bool_fnames = [
        "indexable",
        "indexed",
    ]
    metadata = taxcalc.Policy().metadata()
    for pname, mdata in metadata.items():
        colnames = "INSERT INTO parameter (name,"
        colvalues = f"VALUES('{pname}',"
        for fname, fvalue in mdata.items():
            if fname in str_fnames:
                colnames += f"{fname},"
                colvalue = fvalue.replace("'", "")
                colvalues += f"'{colvalue}',"
            elif fname in bool_fnames:
                colnames += f"{fname},"
                colvalue = int(fvalue)
                colvalues += f"{colvalue},"
        # add vindex_name, vindex_value_min, and vindex_value_max
        colnames += "vindex_name,vindex_value_min,vindex_value_max) "
        first_value = mdata["value"][0]
        if "MARS" in first_value:
            colvalues += "'MARS',1,5);"
        elif "EIC" in first_value:
            colvalues += "'KIDS',0,3);"
        else:
            colvalues += "'',0,0);"
        try:
            sql = f"{colnames}{colvalues}"
            cur.execute(sql)
            cur.connection.commit()
        except Exception as e:  # pragma: no cover
            raise RuntimeError(f"ERROR: {str({e})} : {sql}") from e
        # add pname-indexed parameter if pname is indexable
        if mdata["indexable"]:
            desc = f"Whether {pname} is inflation indexed"
            sql = f"""
            INSERT INTO parameter
            (name, description, type)
            VALUES('{pname}-indexed', '{desc}', 'bool')
            """
            try:
                cur.execute(sql)
                cur.connection.commit()
            except Exception as e:  # pragma: no cover
                raise RuntimeError(f"ERROR: {str({e})} : {sql}") from e


def add_variable_rows(cur: sqlite3.Cursor) -> None:
    """
    Add variable table rows containing Tax-Calculator records_variables.json
    information using the specified cur SQLite cursor
    """
    # pylint: disable=too-many-locals
    str_fnames = [
        "description",
        "type",
    ]
    bool_fnames = [
        "requires_dumpvars",
    ]
    # Records variables always written to a dumpdb output file (and which
    # therefore do not require being listed in a --dumpvars file) are the
    # BASE_DUMPVARS and MINIMAL_DUMPVARS defined in taxcalc/taxcalcio.py
    always_dumped = [
        "RECID",
        "s006",
        "data_source",
        "XTOT",
        "MARS",
        "expanded_income",
        "iitax",
    ]
    # read Records variable metadata from the records_variables.json file
    varinfo_path = os.path.join(
        taxcalc.Records.VARINFO_FILE_PATH,
        taxcalc.Records.VARINFO_FILE_NAME,
    )
    with open(varinfo_path, "r", encoding="utf-8") as vfile:
        varinfo = json.load(vfile)
    metadata = {**varinfo["read"], **varinfo["calc"]}
    for vname, vinfo in metadata.items():
        mdata = {
            "description": vinfo["desc"],
            "type": vinfo["type"],
            "requires_dumpvars": vname not in always_dumped,
        }
        colnames = "INSERT INTO variable (name,"
        colvalues = f"VALUES('{vname}',"
        for fname, fvalue in mdata.items():
            if fname in str_fnames:
                colnames += f"{fname},"
                colvalue = fvalue.replace("'", "")
                colvalues += f"'{colvalue}',"
            elif fname in bool_fnames:
                colnames += f"{fname},"
                colvalue = int(fvalue)
                colvalues += f"{colvalue},"
        # strip the trailing comma and close the statement
        colnames = f"{colnames[:-1]}) "
        colvalues = f"{colvalues[:-1]});"
        try:
            sql = f"{colnames}{colvalues}"
            cur.execute(sql)
            cur.connection.commit()
        except Exception as e:  # pragma: no cover
            raise RuntimeError(f"ERROR: {str({e})} : {sql}") from e


def create_default_runs_database(
        db_path: Path,
        db_version: int,
) -> None:
    """
    Create SQLite database that stores Tax-Calculator CLI run specifications
    """
    # create tables and indexes plus insert a run table row with default values
    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute("PRAGMA foreign_keys = ON;")
        cur.executescript(CREATE_RUNS_DB_STATEMENTS)
        conn.commit()
        cur.execute("INSERT INTO run DEFAULT VALUES;")
        conn.commit()
        cur.execute(f"INSERT INTO version VALUES ({db_version});")
        conn.commit()
    except Exception as e:
        if conn:
            conn.close()
        raise RuntimeError(f"ERROR: {str({e})} : create runs.db") from e
    # add parameter table and variable table rows
    add_parameter_rows(cur)
    add_variable_rows(cur)
    conn.close()


def need_to_create_default_runs_database(
        db_path: Path,
        db_version: int,
) -> bool:
    """
    Checks for need to create a default runs.db database file,
    returning True if need exists or returning False if there is no need
    """
    if not db_path.exists():
        return True
    # check schema version of existing database
    sql = "SELECT value FROM version;"
    version = select_one_row(db_path, sql)["value"]
    if version == db_version:
        return False
    # schema versions differ
    db_path.rename(Path(str(db_path) + "-old"))
    return True


def check_taxcalc_version(version: str) -> None:
    """
    Check that version is no less than MINIMUM_REQUIRED_TAXCALC_VERSION
    """
    if version < MINIMUM_REQUIRED_TAXCALC_VERSION:
        raise RuntimeError(
            f"Tax-Calculator {version} detected; "
            f"requires >= {MINIMUM_REQUIRED_TAXCALC_VERSION}"
        )


check_taxcalc_version(taxcalc.__version__)
if need_to_create_default_runs_database(RUNS_DB_PATH, RUNS_DB_VERSION):
    create_default_runs_database(RUNS_DB_PATH, RUNS_DB_VERSION)


def database_schema(db_path: Path) -> str:
    """
    Return string containing CREATE TABLE and CREATE INDEX statements
    for SQLite3 database at db_path
    """
    if not db_path.exists():
        return f"Error: database {str(db_path)} does not exist"
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    schema = ""
    # get CREATE TABLE statements
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    for table_tuple in tables:
        table_name = table_tuple[0]
        cursor.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND "
            f"name='{table_name}';"
        )
        statement = cursor.fetchone()[0]
        if statement:
            schema += f"{statement};\n"
    # get CREATE INDEX statements
    cursor.execute("SELECT name FROM sqlite_master WHERE type='index';")
    indexes = cursor.fetchall()
    for index_tuple in indexes:
        index_name = index_tuple[0]
        cursor.execute(
            "SELECT sql FROM sqlite_master WHERE type='index' AND "
            f"name='{index_name}'"
        )
        statement = cursor.fetchone()[0]
        if statement:
            schema += f"{statement};\n"
    # close connection
    conn.close()
    # return schema
    return schema


mcp = MCPServer(
    name="Tax-Calculator-Assistant",
    log_level="WARNING",  # suppresses "INFO" and "NOTICE" MCP log messages
)


def now() -> str:
    """
    Return current ISO-formatted datetime.
    """
    return datetime.now().isoformat(timespec="seconds")


@mcp.tool()
def get_tca_version() -> str:
    """
    Tool returns mcp_server code version and runs.db database version.
    """
    return (
        f"TCA TOOL VERSION = {MCP_SERVER_VERSION} "
        f"and runs.db VERSION = {RUNS_DB_VERSION}\n"
        f"running Tax-Calculator {taxcalc.__version__}"
    )


@mcp.tool()
def get_runs_db_schema() -> str:
    """
    Tool returns runs.db database schema.
    """
    return database_schema(RUNS_DB_PATH)


@mcp.tool()
def query_runs(sql: str) -> str:
    """
    Tool that executes SELECT query on the SQLite runs.db database.

    Arguments:
      - `sql` is string containing a single SQL statement run against runs.db
    Returns:
      - string containing tuple rows generated by the SQL statement
    """
    if "select" not in sql.lower():
        return "Error: query_runs tool expects a SELECT sql statement"
    try:
        conn = sqlite3.connect(str(RUNS_DB_PATH))
        result = conn.cursor().execute(sql).fetchall()
    except Exception as e:
        emsg = f"Error: {str({e})} : {sql}"
    else:
        emsg = ""
    finally:
        if conn:
            conn.close()
    if emsg:
        return emsg
    return "\n".join(str(row) for row in result)


# --- Parameter Management functions and tools:

@mcp.tool()
def get_parameter_values(parameter_names: list, year: int) -> dict[str, Any]:
    """
    Tool that returns values of each parameter in the parameter_names list
    under current-law policy in the specified year.

    Arguments:
      - `parameter_names` is list of strings, each one of which is a key
        in the runs.parameter table
      - `year` is calendar year for which values are obtained

    Returns:
      - dictionary containing parameter information with
        the following structure:
          * "success": bool,
          * "error_msg" : str,
             NOTE that "error_msg" is empty when "success" is True)
          * "values": list of dictionaries, one per parameter, each with
             "name", "description", "type", etc. keys,
             NOTE that "values" list is empty if "success" is False
    """
    edict = {
        "success": False,
        "error_msg": "",
        "values": []
    }
    # check validity of function arguments
    if not isinstance(parameter_names, list):
        edict["error_msg"] = "parameter_names is not a list"
        return edict
    for pname in parameter_names:
        sql = f"SELECT 1 FROM parameter WHERE name='{pname}';"
        select_dict = select_one_row(RUNS_DB_PATH, sql)
        if not select_dict:
            edict["error_msg"] = f"{pname} is an invalid parameter.name"
            return edict
    if not isinstance(year, int):
        edict["error_msg"] = "year is not an integer"
        return edict
    if year < 2013 or year >= 2100:
        edict["error_msg"] = f"{year} is not in [2013,2099] range"
        return edict
    # get current-law policy object for specified year
    pol = taxcalc.Policy()
    pol.set_year(year)
    # construct list of pname: valstr dictionaries
    values = []
    for pname in sorted(parameter_names):
        if pname.endswith("-indexed"):
            pn = pname.replace("-indexed", "")
            sql = f"SELECT indexed FROM parameter WHERE name='{pn}';"
            select_dict = select_one_row(RUNS_DB_PATH, sql)
            boolval = "True" if select_dict["indexed"] == 1 else "False"
            clpval = str(boolval)
        else:
            clpval = str(getattr(pol, pname)[0])
        values.append({pname: clpval})
    return {
        "success": True,
        "error_msg": "",
        "values": values,
    }


# --- Variable Management functions and tools:

@mcp.tool()
def get_variable_info(variable_names: list) -> dict[str, Any]:
    """
    Tool that returns information for each variable in the variable_names list.

    Arguments:
      - `variable_names` is list of strings, each one of which is a key
        in the runs.variable table

    Returns:
      - dictionary containing variable information with
        the following structure:
          * "success": bool,
          * "error_msg" : str,
             NOTE that "error_msg" is empty when "success" is True)
          * "info": list of dictionaries, one per variable, each with
             "name", "description", "type", and "requires_dumpvars" keys
             NOTE that "info" list is empty if "success" is False
    """
    edict = {
        "success": False,
        "error_msg": "",
        "info": []
    }
    # check validity of function arguments
    if not isinstance(variable_names, list):
        edict["error_msg"] = "variable_names is not a list"
        return edict
    # construct list of variable information dictionaries
    info = []
    for vname in variable_names:
        sql = (
            "SELECT name, description, type, requires_dumpvars "
            f"FROM variable WHERE name='{vname}';"
        )
        select_dict = select_one_row(RUNS_DB_PATH, sql)
        if not select_dict:
            edict["error_msg"] = f"{vname} is an invalid variable.name"
            return edict
        info.append(select_dict)
    return {
        "success": True,
        "error_msg": "",
        "info": info,
    }


@mcp.tool()
def write_dumpvars_file(
        filename: str,
        variable_names: list,
) -> dict[str, Any]:
    """
    Tool that writes a --dumpvars file into the working folder (WORK_FOLDER),
    which is the directory in which the Tax-Calculator CLI is executed.  Use
    this tool to create the dumpvars file; do not write the file directly,
    because the CLI reads it from WORK_FOLDER rather than from the repository
    root directory.

    The tool validates each name in variable_names against the runs.variable
    table and keeps only those variables whose requires_dumpvars flag is true
    (variables with a false flag are already in the dumpdb by default and must
    not be listed).  The surviving names are written, whitespace-delimited, to
    WORK_FOLDER/filename.

    Arguments:
      - `filename` is the name of the dumpvars file; it must start with
        'dumpvars-' and end with '.txt'
      - `variable_names` is a list of strings, each one of which should be a
        key in the runs.variable table

    Returns:
      - dictionary containing the following structure:
          * "success": bool,
          * "error_msg": str (empty when "success" is True),
          * "path": str (absolute path of the written file; empty on failure),
          * "written": list of variable names written to the file,
          * "skipped": list of names dropped because requires_dumpvars is false
    """
    edict = {
        "success": False,
        "error_msg": "",
        "path": "",
        "written": [],
        "skipped": [],
    }
    # check validity of function arguments
    if not isinstance(filename, str) or (
            not filename.startswith("dumpvars-")
            or not filename.endswith(".txt")
    ):
        edict["error_msg"] = (
            "filename must start with 'dumpvars-' and end with '.txt'"
        )
        return edict
    if not isinstance(variable_names, list) or not variable_names:
        edict["error_msg"] = "variable_names is not a non-empty list"
        return edict
    # validate each name and partition into written and skipped lists
    written = []
    skipped = []
    for vname in variable_names:
        sql = (
            "SELECT requires_dumpvars "
            f"FROM variable WHERE name='{vname}';"
        )
        select_dict = select_one_row(RUNS_DB_PATH, sql)
        if not select_dict:
            edict["error_msg"] = f"{vname} is an invalid variable.name"
            return edict
        if select_dict["requires_dumpvars"]:
            written.append(vname)
        else:
            skipped.append(vname)
    if not written:
        edict["error_msg"] = (
            "no variable in variable_names requires a --dumpvars file entry"
        )
        edict["skipped"] = skipped
        return edict
    # write the file into WORK_FOLDER
    path = WORK_FOLDER / filename
    with open(str(path), "w", encoding="utf-8") as dvfile:
        dvfile.write(" ".join(written) + "\n")
    return {
        "success": True,
        "error_msg": "",
        "path": str(path),
        "written": written,
        "skipped": skipped,
    }


# --- Policy Management functions and tools:

def policy_is_complete(policy_id: int) -> None:
    """
    Ensures that all vector parameters used in the runs.policy rows for
    policy_id can be completely specified: that is, there is a row for each
    vindex value in each year or missing rows can be added (which is done by
    the nested complete_vector_parameter_specification function).
    """
    # begin nested function
    def complete_vector_parameter_specification(
            pname: str,  # parameter name
            year: int,  # four-digit year
            vindex: str,  # vector index starts with either MARS= or KIDS=
            policy_id: int  # policy whose specification needs completion
    ) -> None:
        """
        Add baseline values to incomplete vector-valued parameter specification
        """
        # check vindex
        vindx = vindex.split("=")[0]
        idx_offset = 1  # MARS in [1,5] range
        if vindx == "KIDS":
            idx_offset = 0  # KIDS in [0,3] range
        # get baseline pval for pname in year
        pol = taxcalc.Policy()
        pol.set_year(year)
        bpval = getattr(pol, pname)[0]
        # add missing values to policy table
        for idx, pval in enumerate(bpval):
            vidx = f"{vindx}={idx + idx_offset}"
            # ... check if policy row is missing
            sql = f"""
            SELECT COUNT(*) as cnt
            FROM policy
            WHERE id = {policy_id}
            AND parameter_name = '{pname}'
            AND year = {year}
            AND vindex = '{vidx}';
            """
            count = select_one_row(RUNS_DB_PATH, sql)["cnt"]
            if count == 1:
                continue  # to top of for loop as policy row is not missing
            # ... insert missing policy row
            sql = f"""
            INSERT INTO policy
            VALUES({policy_id}, '{pname}', {year}, '{vidx}', '{pval}');
            """
            non_select_execution(RUNS_DB_PATH, sql)
    # end nested function

    # check existence of policy specified by policy_id
    sql = f"SELECT COUNT(*) AS cnt FROM policy WHERE id = {policy_id};"
    count = select_one_row(RUNS_DB_PATH, sql)["cnt"]
    if count == 0:
        raise ValueError(f"policy table has no row(s) with id = {policy_id}")
    # get result dictionary for each vector-valued parameter used by policy_id
    sql = f"""
    SELECT parameter_name AS pname, year, count(*) AS cnt, vindex
    FROM policy
    WHERE id = {policy_id} AND vindex != ''
    GROUP by parameter_name, year;
    """
    result_list = select_all_rows(RUNS_DB_PATH, sql)
    # check result dictionary for each row in vector-valued param result_list
    for result in result_list:
        vidx = result["vindex"].split("=")[0]
        assert vidx in ("MARS", "KIDS")
        exp_cnt = 5  # if vidx == "MARS"
        if vidx == "KIDS":
            exp_cnt = 4
        if result["cnt"] != exp_cnt:
            # complete the incomplete vector-valued parameter specification
            complete_vector_parameter_specification(
                result["pname"], result["year"], result["vindex"], policy_id
            )
    return ""


def policy_file_name(policy_id: int) -> str:
    """
    Returns policy file name for specified policy_id.
    """
    return f"policy{policy_id}.json"


def policy_file_path(policy_id: int) -> Path:
    """
    Returns policy file path for specified policy_id.
    """
    return WORK_FOLDER / policy_file_name(policy_id)


def write_json_policy_file(policy_id: int) -> None:
    """
    Writes JSON policy file for policy_id unless policy_id
    does not exist in which case a ValueError is raised.
    """
    # pylint: disable=too-many-locals
    # check existence of policy specified by policy_id
    sql = f"SELECT COUNT(*) AS cnt FROM policy WHERE id = {policy_id};"
    count = select_one_row(RUNS_DB_PATH, sql)["cnt"]
    if count == 0:
        raise ValueError(f"policy table has no row(s) with id = {policy_id}")
    # make sure policy is complete
    policy_is_complete(policy_id)
    # get list of policy element dictionaries
    sql = f"""
    SELECT *
    FROM policy
    WHERE id = {policy_id}
    ORDER BY parameter_name, year, vindex;
    """
    element_dict_list = select_all_rows(RUNS_DB_PATH, sql)
    # write JSON policy file for policy_id
    lbrace = "{"
    rbrace = "}"
    vindex_last_count = {"MARS": 5, "KIDS": 4}
    with open(policy_file_path(policy_id), "w", encoding="utf-8") as jfile:
        jfile.write("{\n")
        last_idx = len(element_dict_list)
        vindex_count = 0
        for idx, element_dict in enumerate(element_dict_list, start=1):
            pname = element_dict["parameter_name"]
            year = element_dict["year"]
            vindex = element_dict["vindex"]
            evalue = element_dict["value"]
            if vindex:
                last_count = vindex_last_count[vindex.split("=")[0]]
                vindex_count += 1
                if vindex_count == 1:
                    value = f"[{evalue}, "
                    continue  # to top of for loop to get next list element
                if vindex_count == last_count:
                    value += f"{evalue}]"
                else:
                    value += f"{evalue}, "
                    continue  # to top of for loop to get next list element
            else:  # if vindex is empty (that is, a scalar parameter)
                value = evalue
            jfile.write(f'    "{pname}": {lbrace}"{year}": {value}{rbrace}')
            vindex_count = 0
            if idx == last_idx:
                jfile.write("\n")
            else:
                jfile.write(",\n")
        jfile.write("}\n")


@mcp.tool()
def create_policy_like(new_id: int, like_id: int) -> str:
    """
    Tool that creates new policy with new_id that is like policy with like_id.

    Arguments:
      - `new_id` is value of id column in the policy table of the new policy
      - `like_id` is value of id column in the policy table of the like policy
    Returns:
      - string describing tool results
    """
    # check that policy with id = new_id does not exist
    sql = f"SELECT COUNT(*) AS cnt FROM policy WHERE id = {new_id};"
    count = select_one_row(RUNS_DB_PATH, sql)["cnt"]
    if count == 1:
        raise ValueError(f"policy row with id = {new_id} already exists")
    policy_file_path(new_id).unlink(missing_ok=True)
    # check for existence of policy with id = like_id
    sql = f"SELECT COUNT(*) AS cnt FROM policy WHERE id = {like_id};"
    count = select_one_row(RUNS_DB_PATH, sql)["cnt"]
    if count == 0:
        raise ValueError(f"policy row with id = {like_id} does not exist")
    # ensure that like_id policy is complete
    policy_is_complete(like_id)
    # create new policy with id = new_id
    sql = f"""
    PRAGMA foreign_keys = ON;
    CREATE TEMP TABLE tmp AS SELECT * FROM policy WHERE id = {like_id};
    ALTER TABLE tmp DROP COLUMN id;
    INSERT INTO policy SELECT {new_id}, tmp.* FROM tmp;
    DROP TABLE tmp;
    """
    non_select_execution(RUNS_DB_PATH, sql)
    return f"Created new policy with id = {new_id} like policy {like_id}"


@mcp.tool()
def create_policy_element(
        policy_id: int,
        parameter_name: str,
        year: int,
        vindex: str,
        value: str,
) -> str:
    """
    Tool that adds a new row in the runs.policy table.

    Use the query_runs tool to find the correct `vindex` for `parameter_name`;
    the correct `vindex` is vindex_name in the parameter table for name equal
    to `parameter_name`.

    Arguments:
      - `policy_id` is value of id column in policy table
      - `parameter_name` is value of parameter_name column in policy table
      - `year` is value of year column in policy table, which specifies the
            year for which this policy element applies and is unrelated to
            value of the run table's taxyear
      - `vindex` is value of vindex column in policy table
           VALID: '' for scalar parameter
           VALID: 'MARS=M' where M is in [1,5] range for MARS-indexed parameter
           VALID: 'KIDS=K' where K is in [0,3] range for KIDS-indexed parameter
      - `value` is value of value column in policy table expressed as a string

    The filing status variable, MARS, denotes these situations:
     - MARS=1 denotes single individuals without any kids
     - MARS=2 denotes married individuals filing joint return
     - MARS=3 denotes married individuals filing separate return
     - MARS=4 denotes heads of households (single individuals with kids)
     - MARS=5 denotes surviving spouses (recently widowed individuals)

    IMPORTANT: Only create policy elements for parameter values that are
    actually changed by a reform.  Do not create elements for all KIDS
    or all MARS indices unless the reform explicitly modifies all of them.
    The policy_is_complete() function will automatically fill in values
    that are unchanged by a reform.

    Returns:
      - string containing success or failure statement regarding whether or
        not the policy table row insert succeeded.
    """
    # pylint: disable=too-many-return-statements,too-many-branches
    policy_file_path(policy_id).unlink(missing_ok=True)
    # check validity of policy_id
    if policy_id < 1:
        return f"Error: policy_id = {policy_id} is less than one"
    # check validity of year
    if year < 2013 or year >= 2100:
        return f"Error: year = {year} is not in [2013,2099] range"
    # get type and vindex values for parameter_name from parameter table
    sql = f"""
    SELECT type, vindex_name FROM parameter
    WHERE name='{parameter_name}';
    """
    param_dict = select_one_row(RUNS_DB_PATH, sql)
    if not param_dict:
        raise ValueError(
            f"no row in parameter table with name = {parameter_name}"
        )
    # check validity of vindex
    vidx = vindex.replace(" ", "")  # remove all spaces from vindex
    if vidx:
        if param_dict["vindex_name"] == "":
            return f"Error: illegal vidx {vidx} (should be '' for scalar)"
        if "=" not in vidx:
            return f"Error: illegal vidx {vidx} (no = character)"
        vidx_list = vidx.split("=")
        if len(vidx_list) != 2:
            return f"Error: illegal vidx {vidx} (not two substrings around =)"
        vidx_name = vidx_list[0]
        valid_vidx_name = param_dict["vindex_name"]
        if vidx_name != valid_vidx_name:
            return (
                f"Error: illegal vidx_name {vidx_name}; "
                f"should be {valid_vidx_name}"
            )
        try:
            vidx_value = int(vidx_list[1])
        except Exception:
            return f"Error: illegal vidx {vidx} (invalid substring after =)"
        if vidx_name == "MARS":
            if vidx_value < 1 or vidx_value > 5:
                return f"Error: illegal vidx {vidx} (MARS not in [1,5] range)"
        elif vidx_name == "KIDS":
            if vidx_value < 0 or vidx_value > 3:
                return f"Error: illegal vidx {vidx} (KIDS not in [0,3] range)"
    # check validity of value
    if not isinstance(value, str):
        return f"Error: value {value} is not a string"
    if param_dict["type"] == "float":
        try:
            _ = float(value)
        except Exception as e:
            return f"Error: illegal float value {value} : {str({e})}"
    elif param_dict["type"] == "int":
        try:
            _ = int(value)
        except Exception as e:
            return f"Error: illegal int value {value} : {str({e})}"
    elif param_dict["type"] == "bool":
        if value not in ["false", "true"]:
            return f"Error: illegal bool value {value} (not false or true)"
    # insert new policy row
    sql = f"""
    INSERT INTO policy
    VALUES({policy_id},'{parameter_name}',{year},'{vidx}','{value}');
    """
    non_select_execution(RUNS_DB_PATH, sql)
    return "Added new row in policy table"


@mcp.tool()
def revise_policy_element(
        policy_id: int,
        parameter_name: str,
        year: int,
        vindex: str,
        value: str,
) -> str:
    """
    Tool that revises value of existing row in the runs.policy table.

    Arguments:
      - `policy_id` is value of id column in policy table
      - `parameter_name` is value of parameter_name column in policy table
      - `year` is value of year column in policy table, which specifies the
            year for which this policy element applies and is unrelated to
            value of the run table's taxyear
      - `vindex` is value of vindex column in policy table
           VALID: '' for scalar parameter
           VALID: 'MARS=M' where M is in [1,5] range for MARS-indexed parameter
           VALID: 'KIDS=K' where K is in [0,3] range for KIDS-indexed parameter
      - `value` is revised value of value column in policy table as a string
    Returns:
      - string containing success or failure statement regarding whether or
        not the policy table row insert succeeded.
    """
    policy_file_path(policy_id).unlink(missing_ok=True)
    # construct WHERE clause
    vidx = vindex.replace(" ", "")  # remove all blanks from vindex
    where_clause = f"""
    WHERE id = {policy_id}
      AND parameter_name = '{parameter_name}'
      AND year = {year}
      AND vindex = '{vidx}'
    """
    # check existence of specified policy table row
    sql = f"SELECT COUNT(*) AS cnt FROM policy {where_clause};"
    count = select_one_row(RUNS_DB_PATH, sql)["cnt"]
    if count == 0:
        raise ValueError(
            f"specified policy table row does not exist for {where_clause}"
        )
    # update value on the policy table row
    if not isinstance(value, str):
        raise ValueError(f"value {value} is not a string")
    sql = f"UPDATE policy SET value='{value}' {where_clause};"
    non_select_execution(RUNS_DB_PATH, sql)
    # call make_run_unstarted for each run that uses policy_id
    # ... look for runs that use policy_id as baseline
    sql = f"""
    SELECT id AS run_id FROM run
    WHERE id IN (
      SELECT run_id FROM run_baseline WHERE policy_id = {policy_id}
    );
    """
    rundict_list = select_all_rows(RUNS_DB_PATH, sql)
    for rundict in rundict_list:
        make_run_unstarted(rundict["run_id"])
    # ... look for runs that use policy_id as reform
    sql = f"""
    SELECT id AS run_id FROM run
    WHERE id IN (
      SELECT run_id FROM run_reform WHERE policy_id = {policy_id}
    );
    """
    rundict_list = select_all_rows(RUNS_DB_PATH, sql)
    for rundict in rundict_list:
        make_run_unstarted(rundict["run_id"])
    return "Revised existing row in policy table"


@mcp.tool()
def delete_policy_element(
        policy_id: int,
        parameter_name: str,
        year: int,
        vindex: str,
) -> str:
    """
    Tool that removes a row from the runs.policy table.

    Arguments:
      - `policy_id` is value of id column in policy table
      - `parameter_name` is value of parameter_name column in policy table
      - `year` is value of year column in policy table
      - `vindex` is value of vindex column in policy table
           VALID: '' for scalar parameter
           VALID: 'MARS=M' where M is in [1,5] range for MARS-indexed parameter
           VALID: 'KIDS=K' where K is in [0,3] range for KIDS-indexed parameter
    Returns:
      - string containing success or failure statement regarding whether or
        not the policy table row delete succeeded.
    """
    policy_file_path(policy_id).unlink(missing_ok=True)
    # remove specified row from runs.policy table
    vidx = vindex.replace(" ", "")  # remove all spaces from vindex
    sql = f"""
    DELETE FROM policy
    WHERE id = {policy_id}
      AND parameter_name = '{parameter_name}'
      AND year = {year}
      AND vindex = '{vidx}';
    """
    non_select_execution(RUNS_DB_PATH, sql)
    # call make_run_unstarted for each run that uses policy_id
    # ... look for runs that use policy_id as baseline
    sql = f"""
    SELECT id AS run_id FROM run
    WHERE id IN (
      SELECT run_id FROM run_baseline WHERE policy_id = {policy_id}
    );
    """
    rundict_list = select_all_rows(RUNS_DB_PATH, sql)
    for rundict in rundict_list:
        make_run_unstarted(rundict["run_id"])
    # ... look for runs that use policy_id as reform
    sql = f"""
    SELECT id AS run_id FROM run
    WHERE id IN (
      SELECT run_id FROM run_reform WHERE policy_id={policy_id}
    );
    """
    rundict_list = select_all_rows(RUNS_DB_PATH, sql)
    for rundict in rundict_list:
        make_run_unstarted(rundict["run_id"])
    return "Deleted policy element and associated run output files"


@mcp.tool()
def delete_policy(policy_id: int) -> str:
    """
    Tool that removes all rows from runs.policy table with specified policy_id.
    """
    policy_file_path(policy_id).unlink(missing_ok=True)
    # remove specified row(s) from runs.policy table
    sql = f"DELETE FROM policy WHERE id = {policy_id};"
    non_select_execution(RUNS_DB_PATH, sql)
    # call make_run_unstarted for each run that uses policy_id
    # ... look for runs that use policy_id as baseline
    sql = f"""
    SELECT id AS run_id FROM run
    WHERE id IN (
      SELECT run_id FROM run_baseline WHERE policy_id = {policy_id}
    );
    """
    rundict_list = select_all_rows(RUNS_DB_PATH, sql)
    for rundict in rundict_list:
        make_run_unstarted(rundict["run_id"])
    # ... look for runs that use policy_id as reform
    sql = f"""
    SELECT id AS run_id FROM run
    WHERE id IN (
      SELECT run_id FROM run_reform WHERE policy_id={policy_id}
    );
    """
    rundict_list = select_all_rows(RUNS_DB_PATH, sql)
    for rundict in rundict_list:
        make_run_unstarted(rundict["run_id"])
    # delete run_baseline rows that use policy_id
    sql = f"""
    DELETE FROM run_baseline WHERE policy_id = {policy_id};
    DELETE FROM run_reform WHERE policy_id = {policy_id};
    """
    non_select_execution(RUNS_DB_PATH, sql)
    return f"Deleted policy {policy_id} and associated run output files"


@mcp.tool()
def get_policy_specification(policy_id: int) -> dict[str, Any]:
    """
    Tool that returns policy specification for policy_id in a dictionary.
    """
    edict = {
        "success": False,
        "error_msg": "",
        "policy_spec": {},
    }
    # get specification of policy with id = policy_id from runs database
    sql = f"""
    SELECT * FROM policy
    WHERE id = {policy_id}
    ORDER BY parameter_name, year, vindex;
    """
    policy_dict_list = select_all_rows(RUNS_DB_PATH, sql)
    if not policy_dict_list:
        edict["error_msg"] = f"no policy with id={policy_id}"
        return edict
    return {
        "success": True,
        "error_msg": "",
        "policy_spec": policy_dict_list[0],
    }


@mcp.tool()
def write_policy_file(policy_id: int) -> str:
    """
    Tool that writes policy file for specified policy_id.
    """
    write_json_policy_file(policy_id)
    return f"Wrote policy file for policy_id = {policy_id}"


# --- Run Management functions and tools:

def make_run_unstarted(run_id: int) -> None:
    """
    Function that specifies existing run with id = run_id as
    unstarted and removes any output files generated by run_id.
    """
    # update run table row with id = run_id
    sql = f"""
    UPDATE run SET
    status = 'unstarted', start_time = '', finish_time = '', exec_errors = ''
    WHERE id = {run_id};
    """
    non_select_execution(RUNS_DB_PATH, sql)
    # remove any output files associated with run_id
    for outpath in WORK_FOLDER.glob(f"run{run_id}-*"):
        outpath.unlink()


def list_of_policy_id_used_by_run(run_id: int) -> dict[str, Any]:
    """
    Returns list of policy.id values used by run with id = run_id
    used as a baseline policy and used as a reform policy.

    Arguments:
      - `run_id` is value of id in the runs.run table
    Returns:
      - dictionary containing two key:value pairs:
        baseline_policy_id_list: list[int] (baseline policy_id used by run)
        reform_policy_id_list: list[int] (reform policy_id used by run)
    """
    # get baseline policy_id values used by run
    baseline_policy_id_list = []
    sql = f"SELECT policy_id FROM run_baseline WHERE run_id = {run_id};"
    baseline_policy_dict_list = select_all_rows(RUNS_DB_PATH, sql)
    for policy_dict in baseline_policy_dict_list:
        baseline_policy_id_list.append(policy_dict["policy_id"])
    # get reform policy_id values used by run
    reform_policy_id_list = []
    sql = f"SELECT policy_id FROM run_reform WHERE run_id = {run_id};"
    reform_policy_dict_list = select_all_rows(RUNS_DB_PATH, sql)
    for policy_dict in reform_policy_dict_list:
        reform_policy_id_list.append(policy_dict["policy_id"])
    # return both policy_id lists in a dictionary
    return {
        "baseline_policy_id_list": baseline_policy_id_list,
        "reform_policy_id_list": reform_policy_id_list,
    }


def run_specification(run_id: int) -> dict[str, Any]:
    """
    Return dictionary containing specification of run with id = run_id;
    return an empty dictionary if no run exisits with run_id.
    """
    sql = f"SELECT * FROM run WHERE id = {run_id};"
    run_dict = select_one_row(RUNS_DB_PATH, sql)
    if not run_dict:
        return {}
    sql = f"SELECT policy_id FROM run_baseline WHERE run_id = {run_id};"
    baseline_policy_id_list = select_all_rows(RUNS_DB_PATH, sql)
    sql = f"SELECT policy_id FROM run_reform WHERE run_id = {run_id};"
    reform_policy_id_list = select_all_rows(RUNS_DB_PATH, sql)
    run_dict["baseline"] = baseline_policy_id_list
    run_dict["reform"] = reform_policy_id_list
    return run_dict


@mcp.tool()
def get_run_specification(run_id: int) -> dict[str, Any]:
    """
    Tool that returns run specification for run_id in a dictionary.
    """
    edict = {
        "success": False,
        "error_msg": "",
        "run_spec": {},
    }
    # get specification of run with id = run_id from runs database
    run_dict = run_specification(run_id)
    if not run_dict:
        edict["error_msg"] = f"no run with id = {run_id}"
        return edict
    return {
        "success": True,
        "error_msg": "",
        "run_spec": run_dict,
    }


@mcp.tool()
def create_run_like(new_id: int, like_id: int) -> str:
    """
    Tool that creates new run with new_id that is like run with like_id.

    Arguments:
      - `new_id` is value of id column in the run table of the new run
      - `like_id` is value of id column in the run table of the like run
    Returns:
      - string describing what was done

    Note: The run table's taxyear and numyears columns specify which tax
    years to simulate (taxyear, ..., taxyear+numyears-1) and thus taxyear
    is unrelated to when policy reforms take effect.  Policy reform
    implementation years are specified in the policy table's year column.
    """
    # check that run with id = new_id does not exist
    sql = f"SELECT COUNT(*) AS cnt FROM run WHERE id = {new_id};"
    count = select_one_row(RUNS_DB_PATH, sql)["cnt"]
    if count == 1:
        raise ValueError(f"run row with id = {new_id} already exists")
    # check for existence of run with id = like_id
    sql = f"SELECT COUNT(*) AS cnt FROM run WHERE id = {like_id};"
    count = select_one_row(RUNS_DB_PATH, sql)["cnt"]
    if count == 0:
        raise ValueError(f"run row with id = {like_id} does not exist")
    # check that each policy used by run with id = like_id is complete
    pdict = list_of_policy_id_used_by_run(like_id)
    all_policy_id_list = list(
        set(pdict["baseline_policy_id_list"] + pdict["reform_policy_id_list"])
    )
    for policy_id in all_policy_id_list:
        policy_is_complete(policy_id)
    # create new run row with id = new_id like that for id = like_id
    sql = f"""
    PRAGMA foreign_keys = ON;
    CREATE TEMP TABLE tmp AS SELECT * FROM run WHERE id = {like_id};
    ALTER TABLE tmp DROP COLUMN id;
    INSERT INTO run SELECT {new_id}, tmp.* FROM tmp;
    DROP TABLE tmp;
    """
    non_select_execution(RUNS_DB_PATH, sql)
    make_run_unstarted(new_id)
    # create new run_baseline rows for new_id like those for like_id
    for pid in pdict["baseline_policy_id_list"]:
        sql = f"INSERT INTO run_baseline VALUES({new_id},{pid});"
        non_select_execution(RUNS_DB_PATH, sql)
    # create new run_reform rows for new_id like those for like_id
    for pid in pdict["reform_policy_id_list"]:
        sql = f"INSERT INTO run_reform VALUES({new_id},{pid});"
        non_select_execution(RUNS_DB_PATH, sql)
    return f"Created new run with id = {new_id} like run {like_id}"


@mcp.tool()
def revise_run(run_id: int, sql: str) -> str:
    """
    Tool that revises existing run with id equal to run_id in run table.

    Arguments:
      - `run_id` is value of id column in the runs.run table of revised run
      - `sql` is string containing one SQL statement that updates the row
    Returns:
      - string containing success or failure statement regarding whether or
        not revision is accomplished

    Note: The run table's taxyear and numyears columns specify which tax
    years to simulate (taxyear, ..., taxyear+numyears-1) and thus taxyear
    is unrelated to when policy reforms take effect.  Policy reform
    implementation years are specified in the policy table's year column.
    """
    # revise run with id = run_id in run table in runs database
    non_select_execution(RUNS_DB_PATH, sql)
    make_run_unstarted(run_id)
    return f"Revised run {run_id} and deleted associated output files"


@mcp.tool()
def delete_run(run_id: int) -> str:
    """
    Tool that removes run with id = run_id from the runs.run table.
    """
    # call make_run_unstarted for run_id to remove any run output files
    make_run_unstarted(run_id)
    # remove run with id = run_id from run table in runs database
    sql = f"DELETE FROM run WHERE id = {run_id};"
    non_select_execution(RUNS_DB_PATH, sql)
    return f"Deleted run {run_id} and associated output files"


@mcp.tool()
def set_run_status_to_unstarted(run_id: int) -> str:
    """
    Tool that removes run with id = run_id from the runs.run table
    and removes any output files associated with run_id.
    """
    make_run_unstarted(run_id)
    return "Made run status unstarted and removed all run output"


@mcp.tool()
def create_run_baseline_policy(run_id: int, policy_id: int) -> str:
    """
    Tool that adds a new row to the runs.run_baseline table so that
    run with run_id uses policy with policy_id as baseline.

    Arguments:
      - `run_id` is value of run_id column in run_baseline table
      - `policy_id` is value of policy_id column in run_baseline table
    Returns:
      - string containing success or failure statement regarding whether or
        not the table row insert succeeded.
    """
    # check existence of run specified by run_id
    sql = f"SELECT COUNT(*) AS cnt FROM run WHERE id = {run_id};"
    count = select_one_row(RUNS_DB_PATH, sql)["cnt"]
    if count != 1:
        raise ValueError(f"run table has no row with id = {run_id}")
    # check existence/completeness of policy specified by policy_id
    policy_is_complete(policy_id)
    # insert row into run_baseline table
    sql = f"INSERT INTO run_baseline VALUES({run_id}, {policy_id});"
    non_select_execution(RUNS_DB_PATH, sql)
    make_run_unstarted(run_id)
    # return success message
    return "Added row to run_baseline table"


@mcp.tool()
def delete_run_baseline_policy(run_id: int, policy_id: int) -> str:
    """
    Tool that removes a row from the runs.run_baseline table so that
    run with run_id does not use policy with policy_id as baseline.

    Arguments:
      - `run_id` is value of run_id column in run_baseline table
      - `policy_id` is value of policy_id column in run_baseline table
    Returns:
      - string containing success or failure statement regarding whether or
        not the table row delete succeeded.
    """
    sql = f"""
    DELETE FROM run_baseline
    WHERE run_id = {run_id} AND policy_id = {policy_id};
    """
    non_select_execution(RUNS_DB_PATH, sql)
    make_run_unstarted(run_id)
    return "Deleted row from run_baseline table"


@mcp.tool()
def create_run_reform_policy(run_id: int, policy_id: int) -> str:
    """
    Tool that adds a new row to the runs.run_reform table so that
    run with run_id uses policy with policy_id as reform.

    Arguments:
      - `run_id` is value of run_id column in run_reform table
      - `policy_id` is value of policy_id column in run_reform table
    Returns:
      - string containing success or failure statement regarding whether or
        not the table row insert succeeded.
    """
    # check existence of run specified by run_id
    sql = f"SELECT COUNT(*) AS cnt FROM run WHERE id = {run_id};"
    count = select_one_row(RUNS_DB_PATH, sql)["cnt"]
    if count != 1:
        raise ValueError(f"run table has no row with id = {run_id}")
    # check existence/completeness of policy specified by policy_id
    policy_is_complete(policy_id)
    # insert row into run_reform table
    sql = f"INSERT INTO run_reform VALUES({run_id}, {policy_id});"
    non_select_execution(RUNS_DB_PATH, sql)
    make_run_unstarted(run_id)
    # return success message
    return "Added row in run_reform table"


@mcp.tool()
def delete_run_reform_policy(run_id: int, policy_id: int) -> str:
    """
    Tool that removes a row from the runs.run_reform table so that
    run with run_id does not use policy with policy_id as reform.

    Arguments:
      - `run_id` is value of run_id column in run_reform table
      - `policy_id` is value of policy_id column in run_reform table
    Returns:
      - string containing success or failure statement regarding whether or
        not the table row delete succeeded.
    """
    sql = f"""
    DELETE FROM run_reform
    WHERE run_id = {run_id} AND policy_id = {policy_id};
    """
    non_select_execution(RUNS_DB_PATH, sql)
    make_run_unstarted(run_id)
    return "Deleted row from run_reform table"


def next_available_id(table: str) -> int:
    """
    Return the next available (unused) id value for the specified table,
    which is one more than the current maximum id (or 1 if table is empty).
    """
    sql = f"SELECT COALESCE(MAX(id), 0) + 1 AS nid FROM {table};"
    return select_one_row(RUNS_DB_PATH, sql)["nid"]


def validate_assump(assump: str) -> str:
    """
    Return an error message if the assump argument is not usable as the
    name of an assumptions file in WORK_FOLDER; otherwise return an empty
    string.  An empty assump argument means no assumptions file is used.

    This is a helper used by the create_run tool; it catches a bad
    assumptions file name when the run is created rather than allowing the
    tc CLI to fail much later when the run is executed.
    """
    if not assump:
        return ""
    if not isinstance(assump, str):
        return f"assump {assump} is not a string"
    if "'" in assump or "/" in assump:
        return (
            f"assump '{assump}' must be a file name in the working folder "
            "containing no quote or path-separator characters"
        )
    if not assump.endswith(".json"):
        return f"assump '{assump}' does not end with '.json'"
    if not (WORK_FOLDER / assump).is_file():
        return (
            f"assump file '{assump}' does not exist in the working folder, "
            f"{WORK_FOLDER}"
        )
    return ""


def validate_behavior(behavior: dict | None) -> dict[str, Any]:
    """
    Validate the behavior argument of the create_run tool and return
    a dictionary with keys 'success', 'error_msg',
    'esf', 'sub', 'inc', and 'cg'.

    The behavior argument is either None (no behavioral response, which is
    the static case) or a dictionary that may contain 'esf', 'sub', 'inc',
    and 'cg' keys whose values are the earnings-shift factor, and the
    substitution, income, and capital-gains elasticities used by the
    Tax-Calculator --behavior option.  Parameter and elasticity signs are
    checked here so that an invalid value is reported in the
    tool's error_msg rather than raising a database CHECK-constraint error.
    """
    edict = {"success": False, "error_msg": "", "esf": 0.0, "sub": 0.0,
             "inc": 0.0, "cg": 0.0}
    if behavior is None:
        edict["success"] = True
        return edict
    if not isinstance(behavior, dict):
        edict["error_msg"] = f"behavior {behavior} is not a dictionary"
        return edict
    unknown = sorted(set(behavior.keys()) - {"esf", "sub", "inc", "cg"})
    if unknown:
        edict["error_msg"] = f"behavior has unknown keys {unknown}"
        return edict
    for key, sign in (("esf", 1.0), ("sub", 1.0), ("inc", -1.0), ("cg", -1.0)):
        if key not in behavior:
            continue
        try:
            value = float(behavior[key])
        except (TypeError, ValueError):
            edict["error_msg"] = (
                f"behavior['{key}'] value {behavior[key]} is not a number"
            )
            return edict
        if value * sign < 0.0:
            relation = "non-negative" if sign > 0.0 else "non-positive"
            edict["error_msg"] = (
                f"behavior['{key}'] value {value} must be {relation}"
            )
            return edict
        edict[key] = value
    edict["success"] = True
    return edict


def create_policy_from_elements(elements: list[dict]) -> dict[str, Any]:
    """
    Create a new policy from a list of policy-element dictionaries and return
    a dictionary with keys 'success', 'error_msg', and 'policy_id'.

    Each element dictionary must contain 'parameter_name', 'year', and
    'value' keys and may contain an optional 'vindex' key (default '').
    This is a helper used by the create_run tool; it performs the
    same per-element validation as the create_policy_element tool.
    """
    policy_id = next_available_id("policy")
    for elem in elements:
        if not isinstance(elem, dict):
            return {
                "success": False,
                "error_msg": f"policy element {elem} is not a dictionary",
                "policy_id": 0,
            }
        missing = [k for k in ("parameter_name", "year", "value")
                   if k not in elem]
        if missing:
            return {
                "success": False,
                "error_msg": f"policy element {elem} missing keys {missing}",
                "policy_id": 0,
            }
        try:
            result = create_policy_element(
                policy_id=policy_id,
                parameter_name=str(elem["parameter_name"]),
                year=int(elem["year"]),
                vindex=str(elem.get("vindex", "")),
                value=str(elem["value"]),
            )
        except Exception as e:  # e.g., unknown parameter_name
            return {"success": False, "error_msg": str(e), "policy_id": 0}
        if result.startswith("Error:"):
            return {"success": False, "error_msg": result, "policy_id": 0}
    return {"success": True, "error_msg": "", "policy_id": policy_id}


@mcp.tool()
def create_run(
        reform: list[dict] | None = None,
        input: str = "cps.csv",
        taxyear: int = 2026,
        numyears: int = 1,
        params: int = 1,
        tables: int = 1,
        graphs: int = 0,
        dumpdb: int = 0,
        dumpvars: str = "",
        baseline: list[dict] | None = None,
        assump: str = "",
        behavior: dict | None = None,
) -> dict[str, Any]:
    """
    Composite tool that builds a complete, ready-to-execute reform run in a
    single call: it creates the reform policy (and an optional custom baseline
    policy), creates the run, sets its options, and links the policies to the
    run.  Prefer this tool over the sequence of create_policy_element,
    create_run_like, revise_run, and create_run_reform_policy calls whenever
    the reform is a straightforward set of parameter changes, because it does
    all of that database bookkeeping server-side (allocating the policy_id
    and run_id itself) and returns the ids it created.

    Arguments:
      - `reform` (list[dict], opt) is a non-empty list of reform
         policy-element dictionaries, each with keys:
           * 'parameter_name' (str) : a name in the runs.parameter table
           * 'year' (int)           : year the provision takes effect
           * 'value' (str)          : the reform value as a string
           * 'vindex' (str, opt)    : '' for a scalar parameter, else
                                      'MARS=M' (M in [1,5]) or 'KIDS=K'
                                      (K in [0,3]); default is ''
         Specify only the vector indices the reform actually changes;
         unchanged indices are filled in automatically with current-law values.
         Omit `reform` (the default) ONLY when the run has no reform policy,
         which means the run's reform policy is current-law policy; with both
         `reform` and `baseline` omitted, the run generates current-law
         results (and all baseline-to-reform differences are zero).
      - `input` (str) is the input data file name (default 'cps.csv')
      - `taxyear` (int) is the first tax year to simulate (default 2026)
      - `numyears` (int) is the number of years to simulate (default 1;
         use 10 for a standard ten-year revenue estimate)
      - `params`, `tables`, `graphs`, `dumpdb` (int, 0 or 1) select which
         output files the run generates (defaults are all 1); `tables` must
         be 1 for the get_aggregate_taxes / execute_run_and_report revenue
         summary to work; `dumpdb` must be 1 for the get_dumpdb_schema /
         query_dumpdb to work
      - `dumpvars` (str) is the name of an optional dumpvars-*.txt file
      - `baseline` (list[dict], opt) is a list of baseline policy-element
         dictionaries in the same form as `reform`; omit it (the default) to
         use current-law policy as the baseline, which is the usual case
      - `assump` (str, opt) is the name of an economic-assumptions JSON file
         that must already exist in the working folder; omit it (the default)
         to use current-law economic assumptions, which is the usual case
      - `behavior` (dict, opt) specifies the behavioral response parameters
         for the reform, with these optional keys:
           * 'esf' (float) : earnings-shift factor, which must be >= 0
           * 'sub' (float) : substitution elasticity, which must be >= 0
           * 'inc' (float) : income elasticity, which must be <= 0
           * 'cg'  (float) : capital-gains elasticity, which must be <= 0
         Omitting a key leaves that elasticity at zero.  Omit the whole
         argument (the default) to get a conventional (static) revenue
         estimate, which is the usual case.  Specify elasticities ONLY when
         the user explicitly asks for a behavioral-response (conventional)
         analysis and states which elasticity values to use; never assume
         elasticity values on the user's behalf, because non-zero
         elasticities change the estimated revenue effect of the reform.

    Returns:
      - dictionary with the following structure:
          * "success": bool,
          * "error_msg": str,      (empty when success is True)
          * "run_id": int,         (id of the created run)
          * "reform_policy_id": int,    (0 when no reform policy is used)
          * "baseline_policy_id": int,  (0 when current-law baseline is used)
          * "run_spec": dict       (specification of the created run)
    """
    # pylint: disable=redefined-builtin,too-many-arguments
    # pylint: disable=too-many-arguments,too-many-positional-arguments
    # pylint: disable=too-many-return-statements,too-many-branches
    # pylint: disable=too-many-locals
    edict = {
        "success": False,
        "error_msg": "",
        "run_id": 0,
        "reform_policy_id": 0,
        "baseline_policy_id": 0,
        "run_spec": {},
    }
    # validate reform argument, which is None when the run has no reform
    if reform is not None:
        if not isinstance(reform, list) or len(reform) < 1:
            edict["error_msg"] = (
                "reform must be None or a non-empty list of dictionaries"
            )
            return edict
    # validate assump and behavior arguments before creating any policy so
    # that an invalid argument leaves no orphan policy rows in the database
    assump_error = validate_assump(assump)
    if assump_error:
        edict["error_msg"] = assump_error
        return edict
    beh = validate_behavior(behavior)
    if not beh["success"]:
        edict["error_msg"] = beh["error_msg"]
        return edict
    # optionally create the reform policy
    reform_policy_id = 0
    if reform:
        ref = create_policy_from_elements(reform)
        if not ref["success"]:
            emsg = ref["error_msg"]
            edict["error_msg"] = f"reform policy error: {emsg}"
            return edict
        reform_policy_id = ref["policy_id"]
    # optionally create a custom baseline policy
    baseline_policy_id = 0
    if baseline:
        bas = create_policy_from_elements(baseline)
        if not bas["success"]:
            emsg = bas["error_msg"]
            edict["error_msg"] = f"baseline policy error: {emsg}"
            return edict
        baseline_policy_id = bas["policy_id"]
    # create the run row with the requested options (other columns default)
    run_id = next_available_id("run")
    sql = f"""
    INSERT INTO run
      (id, input, taxyear, numyears, params, tables, graphs, dumpdb, dumpvars,
       assump, behavior_esf, behavior_sub, behavior_inc, behavior_cg)
    VALUES
      ({run_id}, '{input}', {int(taxyear)}, {int(numyears)},
       {int(bool(params))}, {int(bool(tables))}, {int(bool(graphs))},
       {int(bool(dumpdb))}, '{dumpvars}',
       '{assump}', {beh["esf"]}, {beh["sub"]}, {beh["inc"]}, {beh["cg"]});
    """
    non_select_execution(RUNS_DB_PATH, sql)
    # link the optional reform and baseline policies to the run;
    # these calls also verify policy completeness and reset run status
    if reform_policy_id:
        _ = create_run_reform_policy(run_id, reform_policy_id)
    if baseline_policy_id:
        _ = create_run_baseline_policy(run_id, baseline_policy_id)
    return {
        "success": True,
        "error_msg": "",
        "run_id": run_id,
        "reform_policy_id": reform_policy_id,
        "baseline_policy_id": baseline_policy_id,
        "run_spec": run_specification(run_id),
    }


def assuming_behavior(row: dict) -> bool:
    """
    Constructs br{row["id"].json file from behavior elasticities in row and
    returns True if any elasticity is non-zero; otherwise returns False
    """
    behresp = (
        row["behavior_esf"] > 0.0 or
        row["behavior_sub"] > 0.0 or
        row["behavior_inc"] < 0.0 or
        row["behavior_cg"] < 0.0
    )
    if not behresp:
        return False
    # write brN.json file
    run_id = row["id"]
    br_path = WORK_FOLDER / f"br{run_id}.json"
    br_text = f"""
    {{
        "esf": {row["behavior_esf"]},
        "sub": {row["behavior_sub"]},
        "inc": {row["behavior_inc"]},
        "cg": {row["behavior_cg"]}
    }}
    """
    with open(str(br_path), "w", encoding="utf-8") as brfile:
        brfile.write(br_text)
    return True


@mcp.tool()
def execute_run(run_id: int) -> str:
    """
    Execute tc shell command for run with runs.run.id = run_id.
    """
    # pylint: disable=too-many-statements,too-many-locals,too-many-branches
    # get values from runs.run table row with id equal to run_id
    sql = f"SELECT * FROM run WHERE id = {run_id};"
    row = select_one_row(RUNS_DB_PATH, sql)
    if not row:
        raise ValueError(f"no row in run table with id = {run_id}")
    # check status of run
    if row["status"] != "unstarted":
        raise ValueError(f"run {run_id} status is not unstarted")
    # write JSON policy file for each policy used by run with id = run_id
    pdict = list_of_policy_id_used_by_run(run_id)
    all_policy_id_list = list(set(
        pdict["baseline_policy_id_list"] +
        pdict["reform_policy_id_list"]
    ))
    for policy_id in all_policy_id_list:
        write_json_policy_file(policy_id)
    # construct tc CLI command as list of strings
    tc_executable = shutil.which("tc")
    assert tc_executable is not None, (
        "Cannot locate the `tc` executable. Activate the taxcalc-dev "
        "conda environment before using Tax-Calculator-Assistant."
    )
    tc_path = Path(tc_executable).resolve()
    command = [f'{str(tc_path)}']
    command.extend([f'{row["input"]}', f'{row["taxyear"]}'])
    command.extend(["--numyears", f'{row["numyears"]}', "--exact"])
    if pdict["baseline_policy_id_list"]:
        fnames = []
        for pid in pdict["baseline_policy_id_list"]:
            fnames.append(policy_file_name(pid))
        fnames_str = "+".join(str(fname) for fname in fnames)
        command.extend(["--baseline", f"{fnames_str}"])
    if pdict["reform_policy_id_list"]:
        fnames = []
        for pid in pdict["reform_policy_id_list"]:
            fnames.append(policy_file_name(pid))
        fnames_str = "+".join(str(fname) for fname in fnames)
        command.extend(["--reform", f"{fnames_str}"])
    if row["assump"]:
        assump_filename = row["assump"]
        command.extend(["--assump", f"{assump_filename}"])
    if assuming_behavior(row):
        command.extend(["--behavior", f"br{run_id}.json"])
    if row["params"] == 1:
        command.append("--params")
    if row["tables"] == 1:
        command.append("--tables")
    if row["graphs"] == 1:
        command.append("--graphs")
    if row["dumpdb"] == 1:
        command.append("--dumpdb")
    if row["dumpvars"]:
        dumpvars_filename = row["dumpvars"]
        command.extend(["--dumpvars", f"{dumpvars_filename}"])
    command.extend(["--runid", f'{row["id"]}', "--silent"])
    # execute command in a new subprocess
    exec_process = subprocess.Popen(  # pylint: disable=consider-using-with
        command,
        cwd=f"{str(WORK_FOLDER)}",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    xpid = exec_process.pid
    start_time = now()
    # launch another subprocess to monitor run execution
    python_executable = shutil.which("python")
    python_path = Path(python_executable).resolve()
    monitor_path = MCP_SERVER_FOLDER / "monitor_run_execution.py"
    command = [f"{str(python_path)}"]
    command.append(f"{str(monitor_path)}")
    command.append(f"{run_id}")
    command.append(f"{xpid}")
    _ = subprocess.Popen(  # pylint: disable=consider-using-with
        command,
        cwd=f"{str(WORK_FOLDER)}",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    # update status and pid and start_time in runs.run table
    sql = f"""
    UPDATE run SET
      status='started', start_time="{start_time}"
    WHERE id = {run_id};
    """
    non_select_execution(RUNS_DB_PATH, sql)
    # return description of what was done
    return f"Run {run_id} has started execution"


@mcp.tool()
def wait_for_run(run_id: int, timeout_seconds: int = 900) -> dict[str, Any]:
    """
    Tool that waits for run with runs.run.id = run_id to finish executing.
    Call this immediately after execute_run: it does not return until the
    run status is 'finished' or until timeout_seconds have elapsed.

    Arguments:
      - `run_id` is the id of a run that has already started execution
      - `timeout_seconds` is the maximum number of seconds to wait
    Returns:
      - dictionary containing run execution information with the following
        structure:
          * "success": bool,   (False if run did not finish before timeout)
          * "error_msg": str,  (error_msg is empty when success is True)
          * "status": str,     (run status when this tool returned)
          * "exec_errors": str (run execution errors; empty if there are none)
    """
    sql = f"SELECT status, exec_errors FROM run WHERE id = {run_id};"
    row = select_one_row(RUNS_DB_PATH, sql)
    if not row:
        raise ValueError(f"no row in run table with id = {run_id}")
    if row["status"] == "unstarted":
        raise ValueError(f"run {run_id} has not started execution")
    pause_seconds = 1
    waited_seconds = 0
    while row["status"] != "finished":
        if waited_seconds >= timeout_seconds:
            status = row["status"]
            return {
                "success": False,
                "error_msg": (
                    f"run {run_id} status is still {status} after "
                    f"waiting {timeout_seconds} seconds"
                ),
                "status": status,
                "exec_errors": row["exec_errors"],
            }
        time.sleep(pause_seconds)
        waited_seconds += pause_seconds
        row = select_one_row(RUNS_DB_PATH, sql)
    return {
        "success": True,
        "error_msg": "",
        "status": row["status"],
        "exec_errors": row["exec_errors"],
    }


@mcp.tool()
def execute_run_and_report(
        run_id: int,
        timeout_seconds: int = 900,
) -> dict[str, Any]:
    """
    Composite tool that executes a run, waits for it to finish, checks for
    execution errors, and returns the aggregate tax results -- all in one
    call.  Prefer this tool over the separate execute_run, wait_for_run, and
    get_aggregate_taxes sequence: it collapses that multi-turn interaction
    into a single tool call, so it does not return until the run is finished
    (or timeout_seconds have elapsed).  The run must already be fully set up
    and have 'unstarted' status (for example, as made by create_run).

    Arguments:
      - `run_id` is the id of an unstarted, fully-specified run
      - `timeout_seconds` is the maximum number of seconds to wait for the
         run to finish executing

    Returns:
      - dictionary with the following structure:
          * "success": bool,      (True only if the run finished with no
                                    execution errors and aggregate taxes were
                                    obtained)
          * "error_msg": str,     (empty when success is True)
          * "status": str,        (run status when this tool returned)
          * "exec_errors": str,   (run execution errors; empty if there
                                    are none)
          * "num_years": int,     (number of years aggregated)
          * "tax_units": str,     ("billions")
          * "iitax": dict,        (baseline/reform/difference income taxes;
                                    empty if aggregate taxes were not obtained)
          * "payrolltax": dict    (baseline/reform/difference payroll taxes;
                                    empty if aggregate taxes were not obtained)
    """
    # pylint: disable=too-many-return-statements
    edict = {
        "success": False,
        "error_msg": "",
        "status": "",
        "exec_errors": "",
        "num_years": 0,
        "tax_units": "billions",
        "iitax": {},
        "payrolltax": {},
    }
    # start run execution
    try:
        _ = execute_run(run_id)
    except Exception as e:
        edict["error_msg"] = str(e)
        return edict
    # wait for run to finish executing
    wdict = wait_for_run(run_id, timeout_seconds)
    edict["status"] = wdict["status"]
    edict["exec_errors"] = wdict["exec_errors"]
    if not wdict["success"]:  # pragma: no cover
        edict["error_msg"] = wdict["error_msg"]
        return edict
    if wdict["exec_errors"]:  # pragma: no cover
        edict["error_msg"] = "run finished with execution errors"
        return edict
    # collect the tables output names and aggregate the taxes over them
    names = run_kind_output_names(run_id, "tables")
    if not names:
        edict["error_msg"] = (
            f"run {run_id} produced no tables output; "
            "create the run with tables=1 to get aggregate taxes"
        )
        return edict
    agg = get_aggregate_taxes(names)
    if not agg["success"]:  # pragma: no cover
        edict["error_msg"] = agg["error_msg"]
        return edict
    edict["success"] = True
    edict["num_years"] = agg["num_years"]
    edict["iitax"] = agg["iitax"]
    edict["payrolltax"] = agg["payrolltax"]
    return edict


# --- Output Analysis functions and tools:

@mcp.tool()
def get_dumpdb_schema(output_name: str) -> str:
    """
    Tool returns schema of dumpdb database in {ouput_name}.dumpdb file.

    Argument:
      - `output_name` is string of the form runN-YY
    Returns:
      - string containing dumpdb database schema
    """
    dumpdb_path = WORK_FOLDER / f"{output_name}.dumpdb"
    return database_schema(dumpdb_path)


@mcp.tool()
def run_kind_output_names(run_id: int, output_kind: str) -> list[str]:
    """
    Tool that returns output names for specified run_id and for specified
    output_kind as a list of alphabetized strings, where each string has
    the form runN-YY with N being a positive integer and YY designating
    a year (e.g., 26 for 2026).

    Arguments:
      - `run_id` is integer run id, N
      - `output_kind` is string in ["params", "tables", "graphs", "dumpdb"]
    Returns:
      - list of runN-YY astrings
    """
    # generate list for specified output_kind
    if output_kind == "params":
        names = [
            str(path.stem).removesuffix("-params")
            for path in WORK_FOLDER.glob("*-params.reform")
        ]
    elif output_kind == "tables":
        names = [
            str(path.stem)
            for path in WORK_FOLDER.glob("*.tables")
        ]
    elif output_kind == "graphs":
        names = [
            str(path.stem).removesuffix("-mtr")
            for path in WORK_FOLDER.glob("*-mtr.html")
        ]
    elif output_kind == "dumpdb":
        names = [
            str(path.stem)
            for path in WORK_FOLDER.glob("*.dumpdb")
        ]
    else:
        return []
    # remove names not starting with runN-
    run_prefix = f"run{run_id}-"
    return [name for name in sorted(names) if name.startswith(run_prefix)]


@mcp.tool()
def get_aggregate_taxes(tables_output_names: list[str]) -> dict[str, Any]:
    """
    Tool that returns aggregate taxes for table_output_names in a dictionary.

    Arguments:
      - `tables_output_names` is list of strings, each one of which is of the
         form runN-YY and using the same N value
    Returns:
      - dictionary containing tax information aggregated across all the runN-YY
        with the following structure:
          * "success": bool,
          * "error_msg" : str,  (error_msg is empty when success is True)
          * "num_years" : int,
          * "tax_units": "billions",
          * "iitax": dict[
               "baseline" : float,
               "reform" : float,
               "difference" : float,
               "percentage_difference" : float
               ],
          * "payrolltax": dict[
               "baseline" : float,
               "reform" : float,
               "difference" : float,
               "percentage_difference" : float
               ]
    """
    # pylint: disable=too-many-locals,too-many-statements
    # pylint: disable=too-many-return-statements,too-many-branches
    # check validity of names argument
    edict = {
        "success": False,
        "error_msg": "",
        "num_years": 0,
        "tax_units": "billions",
        "iitax": {},
        "payrolltax": {},
    }
    if not isinstance(tables_output_names, list):
        edict["error_msg"] = "Error: tables_output_names is not a list"
        return edict
    if len(tables_output_names) < 1:
        edict["error_msg"] = "Error: tables_output_names list is empty"
        return edict
    years = []
    for idx, name in enumerate(tables_output_names):
        if not isinstance(name, str):
            edict["error_msg"] = (
                f"Error: tables_output_names item {name} is not a string"
            )
            return edict
        parts = name.split("-")
        if len(parts) != 2:
            edict["error_msg"] = (
                f"Error: tables_output_names item {name} contains not one -"
            )
            return edict
        if idx == 0:
            npart = parts[0]
        else:
            if parts[0] != npart:
                msg = (
                    f"tables_output_names item {name} does "
                    f"not start with {npart}"
                )
                edict["error_msg"] = f"Error: {msg}"
                return edict
        try:
            iyr = int(parts[1])
        except ValueError:
            msg = f"names item {name} has invalid year {parts[1]}"
            edict["error_msg"] = f"Error: {msg}"
            return edict
        if iyr < 0 or iyr > 99:
            msg = f"names item {name} has year {parts[1]} outside 0-99 range"
            edict["error_msg"] = f"Error: {msg}"
            return edict
        years.append(iyr)
    num_yrs = len(years)
    sorted_yrs = sorted(years)
    first_yr = sorted_yrs[0]
    last_yr = sorted_yrs[-1]
    if (last_yr - first_yr + 1) != num_yrs:
        msg = f"names {tables_output_names} does not contain consecutive years"
        edict["error_msg"] = f"Error: {msg}"
        return edict
    # aggregate tax information over the years
    num_years = 0
    agg_itax_ref = 0.0
    agg_ptax_ref = 0.0
    agg_itax_dif = 0.0
    agg_ptax_dif = 0.0
    for name in tables_output_names:
        # read name.tables file into a list of lines
        path = WORK_FOLDER / f"{name}.tables"
        if not path.exists():
            edict["error_msg"] = f"Error: {name}.tables file does not exist"
            return edict
        with open(str(path), "r", encoding="utf-8") as tfile:
            lines = tfile.readlines()
        # extract aggregate reform and difference taxes from lines
        # (aggregate reform taxes are on first line starting with A)
        # (aggregate difference taxes are on second line starting with A)
        num_agg_lines = 0
        for line in lines:
            if not line.startswith(" A"):
                continue
            num_agg_lines += 1
            tokens = line.split()
            if num_agg_lines == 1:
                agg_itax_ref += float(tokens[3])
                agg_ptax_ref += float(tokens[4])
            else:
                agg_itax_dif += float(tokens[3])
                agg_ptax_dif += float(tokens[4])
        if num_agg_lines != 2:
            edict["error_msg"] = f"Error: {name}.tables file is malformed"
            return edict
        num_years += 1
    agg_itax_bas = agg_itax_ref - agg_itax_dif
    agg_ptax_bas = agg_ptax_ref - agg_ptax_dif
    return {
        "success": True,
        "error_msg": "",
        "num_years": num_years,
        "tax_units": "billions",
        "iitax": {
            "baseline": round(agg_itax_bas, 2),
            "reform": round(agg_itax_ref, 2),
            "difference": round(agg_itax_dif, 2),
            "percentage_difference": round(
                100 * agg_itax_dif / agg_itax_bas, 2
            ),
        },
        "payrolltax": {
            "baseline": round(agg_ptax_bas, 2),
            "reform": round(agg_ptax_ref, 2),
            "difference": round(agg_ptax_dif, 2),
            "percentage_difference": round(
                100 * agg_ptax_dif / agg_ptax_bas, 2
            ),
        },
    }


@mcp.tool()
def query_dumpdb(name: str, sql: str) -> str:
    """
    Tool that executes sql statement on SQLite database named `name.dumpdb`.

    Arguments:
      - `name` is string containing an output name of the form runN-YY
      - `sql` is string containing a single SQL statement run against
         the runN-YY.dumpdb (the statement may be a SELECT or other query)
    Returns:
      - string containing tuple rows generated by the SQL statement
    """
    path = WORK_FOLDER / f"{name}.dumpdb"
    if not path.exists():
        return f"Error: {name}.dumpdb file does not exist"
    try:
        conn = sqlite3.connect(path)
        cur = conn.cursor()
        result = cur.execute(sql).fetchall()
        conn.commit()  # for non-select sql statements
        return "\n".join(str(row) for row in result)
    except Exception as e:
        emsg = str(e)
        return f"Error: {emsg} : {sql}"
    finally:
        if conn:
            conn.close()


if __name__ == "__main__":
    mcp.run()  # pragma: no cover
