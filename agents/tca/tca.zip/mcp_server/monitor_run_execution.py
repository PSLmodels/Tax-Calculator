"""
Functions used by Tax-Calculator-Assistant to monitor run execution.
"""
import os
import sys
import time
import sqlite3
from pathlib import Path
from datetime import datetime
import psutil

MCP_SERVER_FOLDER = Path(__file__).parent
DEFAULT_WORK_FOLDER = MCP_SERVER_FOLDER.parent
WORK_FOLDER = Path(os.environ.get("TCA_DIR", str(DEFAULT_WORK_FOLDER)))
RUNS_DB_PATH = WORK_FOLDER / "runs.db"
TCA_LOG_PATH = WORK_FOLDER / "tca.log"


def now() -> str:
    """
    Return current ISO-formatted datetime
    """
    return datetime.now().isoformat(timespec="seconds")


def monitor_run(run_id: int, run_pid: int) -> int:
    """
    Monitor process with run_pid created in execute_run tool until completion
    then updates the runs.run table row for id = run_id
    """
    # periodically check to see if run exeuction process is no longer active
    process = psutil.Process(run_pid)
    pause_seconds = 1
    while True:
        time.sleep(pause_seconds)
        active_process = (
            process.is_running() and process.status() != psutil.STATUS_ZOMBIE
        )
        if not active_process:
            break  # out of while loop
    # check for run execution errors
    errpath = WORK_FOLDER / f"run{run_id}.errors"
    if errpath.exists():
        with open(str(errpath), "r", encoding="utf-8") as efile:
            errtext = efile.read()
        errpath.unlink()
    else:
        errtext = ""
    # update runs.run table with run execution information
    sql = f"""
    UPDATE run SET
      status='finished',
      finish_time='{now()}',
      exec_errors='{errtext}'
    WHERE id={run_id};
    """
    try:
        conn = sqlite3.connect(str(RUNS_DB_PATH))
        conn.execute(sql)
        conn.commit()
    except Exception:  # pylint: disable=broad-exception-caught
        return 1
    # remove behavioral response JSON file
    br_path = WORK_FOLDER / f"br{run_id}.json"
    br_path.unlink(missing_ok=True)
    return 0


if __name__ == "__main__":
    assert len(sys.argv) == 3, "requires exactly two command-line arguments"
    sys.exit(monitor_run(int(sys.argv[1]), int(sys.argv[2])))
