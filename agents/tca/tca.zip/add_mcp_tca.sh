#!/bin/zsh
if claude mcp list | grep -q tca; then
    ;  # do nothing
else
    claude mcp add tca -- python mcp_server/tc_assistant.py
fi
